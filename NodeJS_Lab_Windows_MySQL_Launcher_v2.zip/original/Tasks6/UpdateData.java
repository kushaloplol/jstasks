import java.sql.*;
import java.util.Scanner;

public class UpdateData {
    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/studentdb", "root", "mgit@5");
             Statement s = con.createStatement()) {

            Scanner sc = new Scanner(System.in);
            System.out.print("Enter student id, name, age, email: ");
            int id = sc.nextInt();
            String name = sc.next();
            int age = sc.nextInt();
            String email = sc.next();

            String sql = "UPDATE students SET name='" + name +
                    "', age='" + age + "',email='" + email + "' WHERE id=" + id;
            s.executeUpdate(sql);
            System.out.println("Data updated successfully");
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
    }
}
