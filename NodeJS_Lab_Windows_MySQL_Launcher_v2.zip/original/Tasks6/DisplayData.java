import java.sql.*;

public class DisplayData {
    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3307/studentdb", "root", "mgit@5");
             Statement s = con.createStatement()) {

            ResultSet rs = s.executeQuery("SELECT * FROM students");
            System.out.println("id\tname\tage\temail");

            while (rs.next()) {
                System.out.println(rs.getString("id") + "\t" +
                        rs.getString("name") + "\t" +
                        rs.getString("age") + "\t" +
                        rs.getString("email"));
            }
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
    }
}
