const express = require('express');
const mysql = require('mysql2');
const app = express();
app.use(express.json());
const pool = mysql.createPool({
    host: '127.0.0.1',
    user: 'root',
    password: 'mgit@5',
    database: 'collegedb',
    port: 3307
}).promise(); // Use .promise() for async/await support
app.get('/studentdetails', async (req, res) => {
    try {
   const [rows] = await pool.query('SELECT * FROM studentdetails');
        res.json(rows);
    } catch (err) {
               res.status(500).json({
                 message: err.message
                  });
    }
});
app.post('/studentdetails', async (req, res) => {
    const { name,course} = req.body;
    try {
        const [result] = await pool.execute(
            'INSERT INTO studentdetails (name,course) VALUES (?, ?)',
            [name,course]
        );
        res.status(201).json({ id: result.insertId, name,course});
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.put('/studentdetails/:id', async (req, res) => {
    const { id } = req.params;
    const { name,course} = req.body;
    try {
        const [result] = await pool.execute(
    'UPDATE studentdetails SET name = ?,course = ? WHERE id = ?',
            [name,course,id]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Student not found" });
        }
        res.json({ message: "Student updated successfully", id, name, course});
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.delete('/studentdetails/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await pool.execute('DELETE FROM studentdetails WHERE id = ?', [id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Student not found" });
        }
        res.json({ message: `Student with ID ${id} deleted successfully` });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.listen(3000, () => console.log('Server running on port 3000'));
