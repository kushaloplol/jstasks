# Confirmed task mapping

| Task | Supplied program | Launch/use |
|---|---|---|
| 4 | WeatherInfo2_1.html | Enter city; real values require an OpenWeather key |
| 5 | books.xml, booksinfor.dtd, books.xsd | Opens https://www.xmlvalidation.com/ and local XML files folder; upload/validate manually |
| 6 | InsertData, DisplayData, UpdateData, DeleteData | Java CRUD submenu; JDBC to private MySQL |
| 7 | registration.html + RegisterServlet | `/Task7/registration.html`; POST `/Task7/RegisterServlet` |
| 8 | cookie.html + session.html; five servlets | `/Task8/login`, `/retrieve`, `/login1`, `/retrieve1`, `/LogoutServlet`; mappings unchanged |
| 9 | event1.js, os.js, path.js, server.js | Node example submenu; server returns supplied greeting |
| 10 | Task10/app.js | GET/POST `/studentdetails`; PUT/DELETE `/studentdetails/:id` |
| 11 | Task11/app.js | POST `/login`; GET/POST `/studentdetails1`; PUT/DELETE `/studentdetails1/:id`; Bearer JWT required |
| 12 | stu-mgmt React project | `/`, `/register`, `/login`, `/about`, `/contact`; frontend only |

JSON POST/PUT bodies for Tasks 10–11 contain `name` and `course`. The supplied login body for Task 11 contains `username` and `password`; see its source for the supplied demonstration values. JWT expiry remains seven days. Missing-record PUT and DELETE return the supplied 404 responses. No single-record GET route was invented.

The updated archive contains 50 code/project files after excluding supplied output screenshots and no nested archives. The top-level original README is documentation; the other 49 files are automatically placed with their task. Task 12 package-lock.json was parsed in full (1,318 package entries, registry.npmjs.org URLs) and retained byte-for-byte.
