[CmdletBinding()]
param(
 [ValidateSet('Menu','Prepare','Run','Stop','Status','Hashes')][string]$Action='Menu',
 [ValidateSet('4','5','6','7','8','9','10','11','12','All')][string]$Task='All',
 [string]$LabHome='',
 [string]$Program='',
 [switch]$NoBrowser
)
$ErrorActionPreference='Stop'
if (![Environment]::Is64BitOperatingSystem) { throw 'This lab launcher requires 64-bit Windows.' }
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$Root=Split-Path $PSScriptRoot -Parent
if (!$LabHome) { $LabHome=Join-Path $Root 'lab' }
$LabHome=[IO.Path]::GetFullPath($LabHome)
$Tools=Join-Path $LabHome 'tools'
$Downloads=Join-Path $LabHome 'downloads'
$Logs=Join-Path $LabHome 'logs'
$Code=Join-Path $Root 'code'
$Deploy=Join-Path $LabHome 'working'
$StatePath=Join-Path $LabHome 'state.json'
$Utf8=New-Object Text.UTF8Encoding($false)
New-Item -ItemType Directory -Force -Path $Tools,$Downloads,$Logs,$Code,$Deploy | Out-Null
function Write-Utf8($Path,[string]$Text) {
 New-Item -ItemType Directory -Force -Path (Split-Path $Path -Parent) | Out-Null
 [IO.File]::WriteAllText($Path,$Text,$Utf8)
}
function Get-LabHash([string]$LiteralPath,[string]$Algorithm='SHA256') {
 $stream=[IO.File]::OpenRead($LiteralPath); $hasher=[Security.Cryptography.HashAlgorithm]::Create($Algorithm)
 try { return [pscustomobject]@{Hash=([BitConverter]::ToString($hasher.ComputeHash($stream))).Replace('-','')} }
 finally { $stream.Dispose(); $hasher.Dispose() }
}
function Note([string]$Text) {
 Write-Host $Text
 Add-Content -LiteralPath (Join-Path $Logs 'launcher.log') -Value ("{0:o} {1}" -f (Get-Date),$Text) -Encoding UTF8
}
function Save-State { Write-Utf8 $StatePath ($script:State | ConvertTo-Json -Depth 8) }
function Port-Free([int]$Port) {
 foreach ($endpoint in [Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners()) {
  if ($endpoint.Port -eq $Port) { return $false }
 }
 $listener=New-Object Net.Sockets.TcpListener([Net.IPAddress]::Any,$Port)
 $listener.ExclusiveAddressUse=$true
 try { $listener.Start(); return $true } catch { return $false } finally { $listener.Stop() }
}
function Pick-Port([int]$First) {
 for ($p=$First;$p -lt $First+100;$p++) { if (Port-Free $p) { return $p } }
 throw "No free port in range $First..$($First+99). Close a lab server and retry."
}
if (Test-Path -LiteralPath $StatePath) { $State=Get-Content -LiteralPath $StatePath -Raw | ConvertFrom-Json }
else {
 $State=[pscustomobject]@{Version=1; DbPort=(Pick-Port 13307); TomcatPort=(Pick-Port 18080); Node9Port=(Pick-Port 13009); Node10Port=(Pick-Port 13010); Node11Port=(Pick-Port 13011); ReactPort=(Pick-Port 13012); Processes=@(); Node=''; Java=''; Javac=''; MySQL=''; Tomcat=''; Jdbc=''; DatabaseInitialized=$false }
 Save-State
}
function Fetch($Url,$Path,[int]$Timeout=300) {
 $part="$Path.part"
 Note "Downloading $([IO.Path]::GetFileName($Path)) from $(([uri]$Url).Host)"
 & curl.exe --fail --location --silent --show-error --connect-timeout 20 --max-time $Timeout --retry 1 --retry-max-time $Timeout --output $part $Url
 if ($LASTEXITCODE -ne 0) { throw "Download failed (exit $LASTEXITCODE). Check internet access, then run START.bat again. Partial file: $part" }
 Move-Item -LiteralPath $part -Destination $Path -Force
}
function Download-Checked($Name,$Url,$CheckUrl,$Algorithm) {
 $path=Join-Path $Downloads $Name
 if (!(Test-Path -LiteralPath $path)) { Fetch $Url $path }
 if (!(Test-Path -LiteralPath "$path.check")) { Fetch $CheckUrl "$path.check" 60 }
 $hash=(Get-LabHash -LiteralPath $path -Algorithm $Algorithm).Hash
 $check=Get-Content -LiteralPath "$path.check" -Raw
 # Match the checksum on the named file's line, or a single-hash checksum file.
 $lines=@($check -split "`n" | Where-Object { $_ -match [regex]::Escape($Name) })
 if ($lines.Count) { $check=$lines -join "`n" }
 if ($check -notmatch "(?i)(?<![0-9a-f])$hash(?![0-9a-f])") { throw "Checksum mismatch for $Name. Remove $path and its .check file, then retry." }
 Note "$Name $Algorithm checksum verified."
 return $path
}
function Unzip($Path,$Destination) {
 New-Item -ItemType Directory -Force -Path $Destination | Out-Null
 if (Get-Command tar.exe -ErrorAction SilentlyContinue) {
  & tar.exe -xf $Path -C $Destination
  if ($LASTEXITCODE) { throw "Archive extraction failed (exit $LASTEXITCODE): $Path" }
 } else { Expand-Archive -LiteralPath $Path -DestinationPath $Destination -Force }
}
function Find-Exe($Name) {
 $found=Get-Command $Name -ErrorAction SilentlyContinue | Select-Object -First 1
 if ($found) { return $found.Source }; return ''
}
function Ensure-Node {
 $node=$State.Node
 if (!$node -or !(Test-Path -LiteralPath $node)) { $node=Find-Exe 'node.exe' }
 if ($node) { $v=& $node -p 'process.versions.node'; if ([int]($v.Split('.')[0]) -lt 20) { $node='' } }
 if (!$node) {
  $index=Join-Path $Downloads 'node-index.json'; Fetch 'https://nodejs.org/dist/index.json' $index 60
  $release=Get-Content $index -Raw | ConvertFrom-Json | Where-Object { $_.lts -and $_.version -like 'v24.*' } | Select-Object -First 1
  if (!$release) { throw 'Node 24 LTS not found in official release index.' }
  $name="node-$($release.version)-win-x64.zip"; $url="https://nodejs.org/dist/$($release.version)"
  $zip=Download-Checked $name "$url/$name" "$url/SHASUMS256.txt" 'SHA256'
  Unzip $zip $Tools
  $node=Join-Path $Tools "node-$($release.version)-win-x64\node.exe"
 }
 $State.Node=$node
 $env:PATH="$(Split-Path $node -Parent);$env:PATH"
 $npm=Join-Path (Split-Path $node -Parent) 'npm.cmd'
 if (!(Test-Path -LiteralPath $npm)) { throw "npm.cmd is missing alongside $node. Install the official Node.js LTS distribution." }
 $script:Npm=$npm; Save-State
 Note "Node: $node ($(& $node --version)); npm: $npm"
}
function Ensure-Java {
 $javac=$State.Javac
 if (!$javac -or !(Test-Path -LiteralPath $javac)) { $javac=Find-Exe 'javac.exe' }
 if (!$javac -and $env:JAVA_HOME -and (Test-Path "$env:JAVA_HOME\bin\javac.exe")) { $javac="$env:JAVA_HOME\bin\javac.exe" }
 if ($javac) {
  $priorPreference=$ErrorActionPreference; $ErrorActionPreference='Continue'
  $version=(& $javac -version 2>&1 | Out-String)
  $ErrorActionPreference=$priorPreference
  if ($version -notmatch 'javac\s+(1\.[89]|[89]\.|[1-9][0-9])') { $javac='' }
 }
 if (!$javac) {
  $metadata=Join-Path $Downloads 'jdk.json'
  Fetch 'https://api.adoptium.net/v3/assets/latest/8/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse' $metadata 60
  $asset=@(Get-Content $metadata -Raw | ConvertFrom-Json)[0]; $pkg=$asset.binary.package
  $zip=Join-Path $Downloads $pkg.name
  if (!(Test-Path $zip)) { Fetch $pkg.link $zip }
  if ((Get-LabHash $zip -Algorithm SHA256).Hash -ne $pkg.checksum) { throw 'JDK SHA256 mismatch.' }
  Unzip $zip $Tools
  $javac=(Get-ChildItem $Tools -Filter javac.exe -Recurse | Select-Object -First 1).FullName
 }
 $State.Javac=$javac; $State.Java=Join-Path (Split-Path $javac -Parent) 'java.exe'
 $env:JAVA_HOME=Split-Path (Split-Path $javac -Parent) -Parent
 $env:JRE_HOME=$env:JAVA_HOME
 if (!(Test-Path $State.Java)) { throw "java.exe missing beside $javac" }
 Save-State; Note "JDK compiler: $javac"
}
function Ensure-Jdbc {
 $jar=Download-Checked 'mysql-connector-j-8.4.0.jar' 'https://repo.maven.apache.org/maven2/com/mysql/mysql-connector-j/8.4.0/mysql-connector-j-8.4.0.jar' 'https://repo.maven.apache.org/maven2/com/mysql/mysql-connector-j/8.4.0/mysql-connector-j-8.4.0.jar.sha1' 'SHA1'
 $State.Jdbc=$jar; Save-State
}
function Ensure-MySQL {
 # Reuse compatible binaries while always creating a private lab data directory.
 $mysql=Join-Path $Tools 'mysql-8.4.13-winx64'
 if ($State.MySQL -and (Test-Path "$($State.MySQL)\bin\mysqld.exe")) { $mysql=$State.MySQL }
 if (!(Test-Path "$mysql\bin\mysqld.exe")) {
  $existing=Find-Exe 'mysqld.exe'
  if (!$existing) {
   $common=Join-Path $env:ProgramFiles 'MySQL\MySQL Server 8.4\bin\mysqld.exe'
   if (Test-Path $common) { $existing=$common }
  }
  if (!$existing) {
   foreach ($svc in @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'mysql' })) {
    if ($svc.PathName -match '^"([^"]*mysqld\.exe)"') { $existing=$Matches[1]; break }
   }
  }
  if ($existing) {
   $candidate=Split-Path (Split-Path $existing -Parent) -Parent
   $ver=(& $existing --version | Out-String)
   if ($ver -match 'Ver 8\.4\.' -and $ver -notmatch 'MariaDB' -and (Test-Path "$candidate\bin\mysql.exe")) { $mysql=$candidate; Note "Reusing compatible MySQL 8.4 binaries: $mysql; existing databases are untouched." }
  }
 }
 if (!(Test-Path "$mysql\bin\mysqld.exe")) {
  $name='mysql-8.4.13-winx64.zip'; $zip=Join-Path $Downloads $name
  if (!(Test-Path $zip)) { Fetch "https://cdn.mysql.com/Downloads/MySQL-8.4/$name" $zip }
  # Published by Oracle on https://dev.mysql.com/downloads/mysql/8.4.html?os=3
  if ((Get-LabHash $zip 'MD5').Hash -ne '7b94489d5524dea9b27097068bea25a8') { throw "MySQL published checksum mismatch. Remove $zip and retry." }
  Note 'MySQL ZIP published MD5 checksum verified; extraction follows.'
  Unzip $zip $Tools
 }
 $version=(& "$mysql\bin\mysqld.exe" --version | Out-String)
 if ($LASTEXITCODE -eq -1073741515) {
  Install-VC-Runtime
  $version=(& "$mysql\bin\mysqld.exe" --version | Out-String)
 }
 if ($version -notmatch 'Ver 8\.4\.' -or $version -match 'MariaDB') { throw 'A compatible Oracle MySQL 8.4 server is required.' }
 $State.MySQL=$mysql
 $data=Join-Path $LabHome 'mysql-data'
 if (!(Test-Path "$data\mysql")) {
  if ((Test-Path $data) -and @(Get-ChildItem -LiteralPath $data -Force).Count) { throw "Refusing to initialize a nonempty database folder: $data. Inspect the initialization log; move aside only this private incomplete folder before retrying." }
  Note "Initializing private MySQL data folder: $data (no Windows service; no administrator required)."
  $args=@('--no-defaults','--initialize-insecure',('--basedir="{0}"' -f $mysql),('--datadir="{0}"' -f $data),'--console')
  $p=Start-Process -FilePath "$mysql\bin\mysqld.exe" -ArgumentList $args -WindowStyle Hidden -PassThru -RedirectStandardOutput "$Logs\mysql-init.out.log" -RedirectStandardError "$Logs\mysql-init.err.log"
  if (!$p.WaitForExit(180000)) { Stop-Process -InputObject $p -Force; throw "MySQL initialization timed out. See $Logs\mysql-init.err.log" }
  if ($p.ExitCode -eq -1073741515) {
   Install-VC-Runtime
   throw 'VC++ runtime installed. Run START.bat again to resume MySQL setup.'
  }
  if ($p.ExitCode) { throw "MySQL initialization failed (exit $($p.ExitCode)). See $Logs\mysql-init.err.log." }
 }
 Save-State
}
function Install-VC-Runtime {
 $installer=Join-Path $Downloads 'vc_redist.x64.exe'
 Fetch 'https://aka.ms/vs/17/release/vc_redist.x64.exe' $installer
 $sig=Get-AuthenticodeSignature -FilePath $installer
 if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Microsoft Corporation') { throw 'Microsoft VC++ installer signature could not be verified.' }
 Note 'Windows administrator approval is needed to install the missing Microsoft VC++ runtime. Approve the Windows UAC prompt to continue.'
 try { $p=Start-Process -FilePath $installer -ArgumentList '/install','/passive','/norestart' -Verb RunAs -Wait -PassThru }
 catch { throw 'VC++ runtime installation was cancelled or blocked. Setup progress is retained; run START.bat again when administrator approval is available.' }
 if ($p.ExitCode -notin @(0,1638,3010)) { throw "VC++ runtime installer failed with exit code $($p.ExitCode)." }
 if ($p.ExitCode -eq 3010) { throw 'VC++ runtime installed; Windows requires a restart. Restart Windows, then run START.bat to resume.' }
}
function Owned-Process($Entry) {
 $proc=Get-Process -Id $Entry.Pid -ErrorAction SilentlyContinue
 if (!$proc) { return $null }
 try {
  if ($proc.Path -ne $Entry.Exe -or $proc.StartTime.ToUniversalTime().Ticks.ToString() -ne $Entry.StartTicks) { return $null }
 } catch { return $null }
 return $proc
}
function Start-Owned($Name,$Exe,[string[]]$Arguments,$Working) {
 $entry=@($State.Processes | Where-Object { $_.Name -eq $Name }) | Select-Object -First 1
 if ($entry -and (Owned-Process $entry)) { Note "$Name already running, PID $($entry.Pid)."; return $entry.Pid }
 $safeArgs=@($Arguments | ForEach-Object { if ($_ -match '[\s"]') { '"'+$_.Replace('"','\"')+'"' } else { $_ } })
 $p=Start-Process -FilePath $Exe -ArgumentList $safeArgs -WorkingDirectory $Working -WindowStyle Hidden -PassThru -RedirectStandardOutput "$Logs\$Name.out.log" -RedirectStandardError "$Logs\$Name.err.log"
 Start-Sleep -Milliseconds 400
 if ($p.HasExited) { throw "$Name exited with code $($p.ExitCode). See $Logs\$Name.err.log" }
 $State.Processes=@($State.Processes | Where-Object { $_.Name -ne $Name }) + [pscustomobject]@{Name=$Name;Pid=$p.Id;Exe=$Exe;StartTicks=$p.StartTime.ToUniversalTime().Ticks.ToString()}
 Save-State; Note "$Name started, PID $($p.Id). Logs: $Logs\$Name.*.log"
 return $p.Id
}
function Wait-Port($Port,[int]$Seconds=40) {
 for ($i=0;$i -lt $Seconds;$i++) {
  $c=New-Object Net.Sockets.TcpClient
  try { $a=$c.BeginConnect('127.0.0.1',$Port,$null,$null); if ($a.AsyncWaitHandle.WaitOne(200)) { $c.EndConnect($a); return } } catch {} finally { $c.Dispose() }
  Start-Sleep -Milliseconds 800
 }
 throw "Server did not open port $Port within $Seconds seconds. Inspect $Logs."
}
function Db-Sql([string]$Sql,[switch]$Bootstrap) {
 $ErrorActionPreference='Continue'
 $client=Join-Path $State.MySQL 'bin\mysql.exe'
 $cfg=Join-Path $LabHome 'client.ini'
 $auth=''
 if (!$Bootstrap) { $auth="password=mgit@5`r`n" }
 Write-Utf8 $cfg "[client]`r`nprotocol=tcp`r`nhost=127.0.0.1`r`nport=$($State.DbPort)`r`nuser=root`r`n$auth"
 try {
  $result=$Sql | & $client "--defaults-file=$cfg" '--no-login-paths' '--batch' '--skip-column-names' 2>&1
  if ($LASTEXITCODE) { throw "Database command failed (exit $LASTEXITCODE). Check private server logs. Credentials were omitted from the log." }
  return $result
 } finally { Remove-Item -LiteralPath $cfg -Force -ErrorAction SilentlyContinue }
}
function Start-Database {
 Ensure-MySQL
 $entry=@($State.Processes | Where-Object Name -eq 'database') | Select-Object -First 1
 if (!$entry -or !(Owned-Process $entry)) {
  if (!(Port-Free $State.DbPort)) { $State.DbPort=Pick-Port ($State.DbPort+1); Save-State; Note "Database port conflict resolved: $($State.DbPort). Configuration copies will be refreshed." }
  $data=Join-Path $LabHome 'mysql-data'
  $args=@('--no-defaults',"--basedir=$($State.MySQL)","--datadir=$data",'--bind-address=127.0.0.1',"--port=$($State.DbPort)",'--mysqlx=0','--console',"--pid-file=$LabHome\database.pid")
  Start-Owned 'database' "$($State.MySQL)\bin\mysqld.exe" $args $LabHome | Out-Null
  Wait-Port $State.DbPort
 }
 if (!$State.DatabaseInitialized) {
  # Recover safely if a previous run was interrupted after configuring this private account.
  try { Db-Sql 'SELECT 1;' | Out-Null }
  catch { Db-Sql "ALTER USER 'root'@'localhost' IDENTIFIED BY 'mgit@5';" -Bootstrap | Out-Null }
  $State.DatabaseInitialized=$true; Save-State
 }
 Db-Sql (Get-Content -LiteralPath "$PSScriptRoot\schema.sql" -Raw) | Out-Null
 Note "Private MySQL lab database ready at 127.0.0.1:$($State.DbPort); data folder: $LabHome\mysql-data"
}
function Ensure-Tomcat {
 Ensure-Java; Ensure-Jdbc
 $tomcat=Join-Path $Tools 'apache-tomcat-9.0.123'
 if ($State.Tomcat -and (Test-Path "$($State.Tomcat)\lib\servlet-api.jar")) { $tomcat=$State.Tomcat }
 if (!(Test-Path "$tomcat\lib\servlet-api.jar") -and $env:CATALINA_HOME -and (Test-Path "$env:CATALINA_HOME\lib\catalina.jar")) {
  $version=(& $State.Java '-cp' "$env:CATALINA_HOME\lib\catalina.jar" 'org.apache.catalina.util.ServerInfo' 2>&1 | Out-String)
  if ($version -match 'Apache Tomcat/9\.') { $tomcat=$env:CATALINA_HOME; Note "Reusing compatible Tomcat 9 binaries: $tomcat" }
 }
 if (!(Test-Path "$tomcat\lib\servlet-api.jar")) {
  $zip=Download-Checked 'apache-tomcat-9.0.123.zip' 'https://dlcdn.apache.org/tomcat/tomcat-9/v9.0.123/bin/apache-tomcat-9.0.123.zip' 'https://downloads.apache.org/tomcat/tomcat-9/v9.0.123/bin/apache-tomcat-9.0.123.zip.sha512' 'SHA512'
  Unzip $zip $Tools
 }
 $State.Tomcat=$tomcat; Save-State
 $base=Join-Path $LabHome 'tomcat-base'
 New-Item -ItemType Directory -Force -Path "$base\conf","$base\logs","$base\temp","$base\webapps","$base\work" | Out-Null
 foreach ($f in Get-ChildItem "$tomcat\conf" -File) { if (!(Test-Path "$base\conf\$($f.Name)")) { Copy-Item -LiteralPath $f.FullName -Destination "$base\conf" } }
 $xml=@"
<?xml version="1.0" encoding="UTF-8"?>
<Server port="-1"><Service name="Catalina"><Connector address="127.0.0.1" port="$($State.TomcatPort)" protocol="HTTP/1.1" connectionTimeout="20000"/><Engine name="Catalina" defaultHost="localhost"><Host name="localhost" appBase="webapps" unpackWARs="true" autoDeploy="true"/></Engine></Service></Server>
"@
 Write-Utf8 "$base\conf\server.xml" $xml
 $script:TomcatBase=$base
}
function Configure-Code {
 # Only literals for database URLs/names/passwords and listening ports are changed.
 foreach ($file in Get-ChildItem -LiteralPath "$Root\original" -File -Recurse) {
  $relative=$file.FullName.Substring(("$Root\original").Length+1)
  $dest=Join-Path $Code $relative
  New-Item -ItemType Directory -Force -Path (Split-Path $dest -Parent) | Out-Null
  if ($relative -match '\.(java|js|html)$') {
   $s=[IO.File]::ReadAllText($file.FullName)
   if ($relative -like 'Tasks6\*') { $s=$s.Replace('localhost:3307/studentdb',"127.0.0.1:$($State.DbPort)/lab_studentdb").Replace('localhost:3306/studentdb',"127.0.0.1:$($State.DbPort)/lab_studentdb") }
   if ($relative -eq 'Task7\WEB-INF\classes\RegisterServlet.java') { $s=$s.Replace('localhost:3306/registrationdb5_ _ ',"127.0.0.1:$($State.DbPort)/lab_registrationdb").Replace('"root", " "','"root", "mgit@5"') }
   if ($relative -eq 'Task9\server.js') { $s=$s.Replace('const PORT=3000;',"const PORT=$($State.Node9Port);") }
   if ($relative -eq 'Task10\app.js') { $s=$s.Replace("database: 'collegedb'","database: 'lab_collegedb'").Replace('port: 3307',"port: $($State.DbPort)").Replace('app.listen(3000',"app.listen($($State.Node10Port)").Replace('on port 3000',"on port $($State.Node10Port)") }
   if ($relative -eq 'Task11\app.js') { $s=$s.Replace("database: 'collegedb1'","database: 'lab_collegedb1'").Replace('port: 3307',"port: $($State.DbPort)").Replace('app.listen(3000',"app.listen($($State.Node11Port)").Replace('on port 3000',"on port $($State.Node11Port)") }
   # Retain a previously configured weather key locally; never echo or log it.
   if ($relative -eq 'Task4\WeatherInfo2_1.html' -and (Test-Path $dest)) { $s=[IO.File]::ReadAllText($dest) }
   Write-Utf8 $dest $s
  } else { Copy-Item -LiteralPath $file.FullName -Destination $dest -Force }
 }
}
function Deploy-Folder($Name,$Target='') {
 if (!$Target) { $Target=Join-Path $Deploy $Name }
 New-Item -ItemType Directory -Force -Path $Target | Out-Null
 foreach ($f in Get-ChildItem -LiteralPath "$Code\$Name" -File -Recurse) {
  $rel=$f.FullName.Substring(("$Code\$Name").Length+1); $to=Join-Path $Target $rel
  New-Item -ItemType Directory -Force -Path (Split-Path $to -Parent) | Out-Null
  Copy-Item -LiteralPath $f.FullName -Destination $to -Force
 }
 Note "Source files placed automatically: $Target"
 return $Target
}
function Npm-Install($Path,[switch]$React) {
 Push-Location -LiteralPath $Path
 try {
  $env:npm_config_fetch_retries='1'; $env:npm_config_fetch_timeout='60000'; $env:npm_config_fetch_retry_maxtimeout='15000'
  $marker=Join-Path $Path 'node_modules\.lab-install-ok'
  $lockHash=(Get-LabHash -LiteralPath "$Path\package-lock.json" -Algorithm SHA256).Hash
  if ((Test-Path $marker) -and (Get-Content $marker -Raw).Trim() -eq $lockHash) { Note "Dependencies already installed: $Path"; return }
  Note "Installing npm dependencies in $Path (bounded to 12 minutes)."
  $np=Start-Process -FilePath $env:ComSpec -ArgumentList ('/d /s /c ""{0}" ci --no-audit --no-fund --registry=https://registry.npmjs.org/ > "{1}" 2>&1"' -f $Npm,"$Logs\npm-$([IO.Path]::GetFileName($Path)).log") -WorkingDirectory $Path -WindowStyle Hidden -PassThru
  if (!$np.WaitForExit(720000)) { & taskkill.exe /PID $np.Id /T /F | Out-Null; throw "npm timed out. See $Logs. Retry START.bat; downloaded npm packages remain cached." }
  if ($np.ExitCode) { throw "npm ci failed (exit $($np.ExitCode)). See $Logs\npm-$([IO.Path]::GetFileName($Path)).log. The supplied lockfile was preserved." }
  Write-Utf8 $marker $lockHash
 } finally { Pop-Location }
}
function Refresh-Port($Property) {
 $name=switch ($Property) { 'Node9Port' {'task9'} 'Node10Port' {'task10'} 'Node11Port' {'task11'} 'ReactPort' {'react'} 'TomcatPort' {'tomcat'} }
 $entry=@($State.Processes | Where-Object Name -eq $name) | Select-Object -First 1
 if ($entry -and (Owned-Process $entry)) { return }
 if (!(Port-Free $State.$Property)) { $State.$Property=Pick-Port ($State.$Property+1); Save-State; Note "$Property conflict resolved: $($State.$Property)" }
}
function Prepare-Task([string]$Selected) {
 if ($Selected -eq 'All') { foreach ($t in @('4','5','6','7','8','9','10','11','12')) { Prepare-Task $t }; return }
 if ($Selected -in @('6','7','10','11')) { Start-Database }
 if ($Selected -eq '6') { Ensure-Java; Ensure-Jdbc }
 if ($Selected -in @('7','8')) { Refresh-Port 'TomcatPort'; Ensure-Tomcat }
 if ($Selected -in @('9','10','11','12')) { Ensure-Node }
 if ($Selected -eq '9') { Refresh-Port 'Node9Port' }
 if ($Selected -eq '10') { Refresh-Port 'Node10Port' }
 if ($Selected -eq '11') { Refresh-Port 'Node11Port' }
 if ($Selected -eq '12') { Refresh-Port 'ReactPort' }
 Configure-Code
 switch ($Selected) {
  '4' { Deploy-Folder 'Task4' | Out-Null }
  '5' {
   Deploy-Folder 'Task5' | Out-Null
   Note 'Task 5: XML validation website: https://www.xmlvalidation.com/'
   Note "Upload books.xml from $Deploy\Task5; provide booksinfor.dtd when requested, or select external XML schema and use books.xsd."
   Note 'The supplied first book has no price element, so DTD/XSD validation reports an error. The supplied XML is preserved.'
  }
  {$_ -eq '6'} {
   $p=Deploy-Folder 'Tasks6'; New-Item -ItemType Directory -Force "$p\classes" | Out-Null
   $files=@(Get-ChildItem -LiteralPath $p -Filter '*.java' | ForEach-Object FullName)
   & $State.Javac '-encoding' 'UTF-8' '-cp' $State.Jdbc '-d' "$p\classes" @files
   if ($LASTEXITCODE) { throw "Java compile failed (exit $LASTEXITCODE)." }
  }
  {$_ -in @('7','8')} {
   $p=Deploy-Folder "Task$Selected" "$TomcatBase\webapps\Task$Selected"
   New-Item -ItemType Directory -Force "$p\WEB-INF\lib" | Out-Null
   Copy-Item -LiteralPath $State.Jdbc -Destination "$p\WEB-INF\lib\mysql-connector-j-8.4.0.jar" -Force
   $files=@(Get-ChildItem "$p\WEB-INF\classes" -Filter '*.java' | ForEach-Object FullName)
   & $State.Javac '-encoding' 'UTF-8' '-cp' "$($State.Tomcat)\lib\servlet-api.jar;$($State.Jdbc)" '-d' "$p\WEB-INF\classes" @files
   if ($LASTEXITCODE) { throw "Servlet compilation failed (exit $LASTEXITCODE)." }
  }
  '9' { $p=Deploy-Folder 'Task9'; Write-Utf8 "$p\package.json" '{"private":true,"type":"module"}' }
  {$_ -in @('10','11')} {
   $p=Deploy-Folder "Task$Selected"
   Copy-Item -LiteralPath "$PSScriptRoot\packages\Task$Selected\package.json","$PSScriptRoot\packages\Task$Selected\package-lock.json" -Destination $p -Force
   Npm-Install $p
  }
  '12' { $p=Deploy-Folder 'Task12'; Npm-Install "$p\stu-mgmt" -React }
 }
 Source-Hashes | Out-Null
 Note "Task $Selected prepared. Final configured source: $Code"
}
function Task-Location($Selected) {
 switch ($Selected) {
  '4' { return "$Deploy\Task4\WeatherInfo2_1.html" }
  '5' { return "https://www.xmlvalidation.com/ (local files: $Deploy\Task5)" }
  {$_ -eq '6'} { return "$Deploy\Tasks6" }
  '7' { return "http://127.0.0.1:$($State.TomcatPort)/Task7/registration.html" }
  '8' { return "http://127.0.0.1:$($State.TomcatPort)/Task8/cookie.html and http://127.0.0.1:$($State.TomcatPort)/Task8/session.html" }
  '9' { return "http://127.0.0.1:$($State.Node9Port)/" }
  '10' { return "http://127.0.0.1:$($State.Node10Port)/studentdetails" }
  '11' { return "http://127.0.0.1:$($State.Node11Port)/login (POST); /studentdetails1 requires a Bearer token" }
  '12' { return "http://127.0.0.1:$($State.ReactPort)/" }
 }
}
function Run-Task($Selected,$ChosenProgram) {
 switch ($Selected) {
  '4' {
   $f="$Code\Task4\WeatherInfo2_1.html"; $s=[IO.File]::ReadAllText($f)
   if ($s.Contains("const APIKey = '';")) {
    Write-Host 'OpenWeather API key is required for real weather data. It is stored only in your local HTML working copy.'
    $secure=Read-Host 'Enter key (hidden), or Enter to open the HTML without a key' -AsSecureString
    $key=[Net.NetworkCredential]::new('',$secure).Password
    if (!$key) { Note 'Opening weather HTML without an API key. Real weather data still requires a valid key.' }
    else {
     if ($key -notmatch '^[A-Za-z0-9_-]+$') { throw 'API key contains unsupported characters.' }
     Write-Utf8 $f ($s.Replace("const APIKey = '';","const APIKey = '$key';")); Deploy-Folder 'Task4' | Out-Null; Source-Hashes | Out-Null
    }
   }
   if (!$NoBrowser) { Start-Process -FilePath "$Deploy\Task4\WeatherInfo2_1.html" }
  }
  '5' {
   Note "XML files: $Deploy\Task5\books.xml, $Deploy\Task5\booksinfor.dtd, $Deploy\Task5\books.xsd"
   if (!$NoBrowser) {
    Start-Process -FilePath 'https://www.xmlvalidation.com/'
    Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f "$Deploy\Task5")
   }
  }
  {$_ -eq '6'} {
   if ($ChosenProgram -notin @('InsertData','DisplayData','UpdateData','DeleteData')) { throw 'Choose InsertData, DisplayData, UpdateData or DeleteData.' }
   Note "Command: java -cp `"$Deploy\Tasks6\classes;$($State.Jdbc)`" $ChosenProgram"
   & $State.Java '-cp' "$Deploy\Tasks6\classes;$($State.Jdbc)" $ChosenProgram
   $script:LastTaskExit=$LASTEXITCODE
  }
  {$_ -in @('7','8')} {
   $args=@("-Dcatalina.home=$($State.Tomcat)","-Dcatalina.base=$TomcatBase","-Djava.io.tmpdir=$TomcatBase\temp",'-cp',"$($State.Tomcat)\bin\bootstrap.jar;$($State.Tomcat)\bin\tomcat-juli.jar",'org.apache.catalina.startup.Bootstrap','start')
   Start-Owned 'tomcat' $State.Java $args $TomcatBase | Out-Null; Wait-Port $State.TomcatPort
   if (!$NoBrowser) { $page=if ($Selected -eq '7') {'registration.html'} else {'cookie.html'}; Start-Process "http://127.0.0.1:$($State.TomcatPort)/Task$Selected/$page" }
  }
  '9' {
   $p="$Deploy\Task9"
   if (!$ChosenProgram) { $ChosenProgram='server.js' }
   if ($ChosenProgram -notin @('event1.js','os.js','path.js','server.js')) { throw 'Invalid Task 9 program.' }
   if ($ChosenProgram -eq 'server.js') { Start-Owned 'task9' $State.Node @("$p\server.js") $p | Out-Null; Wait-Port $State.Node9Port }
   else { & $State.Node "$p\$ChosenProgram"; $script:LastTaskExit=$LASTEXITCODE }
  }
  {$_ -in @('10','11')} { $p="$Deploy\Task$Selected"; Start-Owned "task$Selected" $State.Node @("$p\app.js") $p | Out-Null; $port=if ($Selected -eq '10') {$State.Node10Port} else {$State.Node11Port}; Wait-Port $port }
  '12' {
   $p="$Deploy\Task12\stu-mgmt"; $env:PORT=$State.ReactPort.ToString(); $env:HOST='127.0.0.1'; $env:BROWSER='none'
   Start-Owned 'react' $State.Node @("$p\node_modules\react-scripts\scripts\start.js") $p | Out-Null; Wait-Port $State.ReactPort 90
   if (!$NoBrowser) { Start-Process "http://127.0.0.1:$($State.ReactPort)/" }
  }
 }
 if ($Selected -in @('7','8','9','10','11','12')) { Note 'Servers run in the background. Return to this menu to stop lab servers; logs are under lab\logs. Exit stops only launcher-owned processes.' }
}
function Stop-Lab {
 foreach ($entry in @($State.Processes | Sort-Object @{Expression={if ($_.Name -eq 'database') {1} else {0}}})) {
  $proc=Owned-Process $entry
  if ($proc) {
   if ($entry.Name -eq 'database') { try { Db-Sql 'SHUTDOWN;' | Out-Null; $proc.WaitForExit(8000) | Out-Null } catch {} }
   if (!$proc.HasExited) { Stop-Children $proc; Stop-Process -InputObject $proc -Force -ErrorAction SilentlyContinue }
   Note "Stopped owned $($entry.Name) process $($entry.Pid)."
  }
 }
 $State.Processes=@(); Save-State
}
function Stop-Children($ParentProcess) {
 foreach ($child in @(Get-CimInstance Win32_Process -Filter "ParentProcessId=$($ParentProcess.Id)" -ErrorAction SilentlyContinue)) {
  $p=Get-Process -Id $child.ProcessId -ErrorAction SilentlyContinue
  if ($p -and $p.StartTime -ge $ParentProcess.StartTime) {
   Stop-Children $p
   Stop-Process -InputObject $p -Force -ErrorAction SilentlyContinue
   Note "Stopped owned child process $($p.Id)."
  }
 }
}
function Source-Hashes {
 $records=@()
 foreach ($file in Get-ChildItem -LiteralPath $Code -File -Recurse) {
  $rel=$file.FullName.Substring($Code.Length+1); $target=Join-Path $Deploy $rel
  if ($rel -like 'Task7\*' -or $rel -like 'Task8\*') { $target=Join-Path "$LabHome\tomcat-base\webapps" $rel }
  if (Test-Path -LiteralPath $target) {
   $a=(Get-LabHash -LiteralPath $file.FullName -Algorithm SHA256).Hash; $b=(Get-LabHash -LiteralPath $target -Algorithm SHA256).Hash
   $records += [pscustomobject]@{Source=$rel;SHA256=$a;Deployed=$target;DeployedSHA256=$b;Match=($a -eq $b)}
  }
 }
 Write-Utf8 "$LabHome\source-hashes.json" (ConvertTo-Json -InputObject $records -Depth 5)
 if (@($records | Where-Object { !$_.Match }).Count) { throw "Deployed source hashes differ. See $LabHome\source-hashes.json; prepare affected tasks again." }
 return $records
}
function Menu {
 while ($true) {
  Write-Host "`n=== Node.js Lab: Tasks 4-12 ===`n4 Weather`n5 XML validation (DTD / XSD)`n6 Java CRUD`n7 Registration servlet`n8 Cookies / sessions / logout`n9 Node.js examples`n10 Express + MySQL CRUD`n11 JWT + MySQL CRUD`n12 React student UI`nS Stop lab servers`n0 Exit"
  $selected=Read-Host 'Select'
  if ($selected -eq '0' -or $selected -eq 'Exit') { Stop-Lab; return }
  if ($selected -eq 'S') { Stop-Lab; continue }
  if ($selected -notin @('4','5','6','7','8','9','10','11','12')) { Write-Host 'Choose 4-12, S or 0.'; continue }
  try {
   $chosen=''
   if ($selected -eq '6') {
    Write-Host '1 InsertData  2 DisplayData  3 UpdateData  4 DeleteData  0 Back'
    $n=Read-Host 'CRUD program'; if ($n -eq '0') { continue }
    if ($n -notin @('1','2','3','4')) { continue }; $chosen=@('InsertData','DisplayData','UpdateData','DeleteData')[[int]$n-1]
   }
   if ($selected -eq '9') {
    Write-Host '1 event1.js  2 os.js  3 path.js  4 server.js  0 Back'
    $n=Read-Host 'Node program'; if ($n -eq '0') { continue }
    if ($n -notin @('1','2','3','4')) { continue }; $chosen=@('event1.js','os.js','path.js','server.js')[[int]$n-1]
   }
   Prepare-Task $selected
   Write-Host "Files: $Code and $LabHome`nLaunch: $(Task-Location $selected)"
   if ($chosen) { Write-Host "Program: $chosen" }
   if ($selected -eq '6') { Write-Host "Command: `"$($State.Java)`" -cp `"$Deploy\Tasks6\classes;$($State.Jdbc)`" $chosen" }
   $ready=Read-Host 'Type DONE to launch, or Enter to return to menu'
   if ($ready -ceq 'DONE') { Run-Task $selected $chosen; if ($script:LastTaskExit) { Note "Program exit code: $script:LastTaskExit" } }
  } catch { Note "ERROR: $($_.Exception.Message)"; Write-Host 'Correct the error and select the task again. Progress and downloads are retained.' }
 }
}
try {
 switch ($Action) {
  'Menu' { Menu }
  'Prepare' { Prepare-Task $Task }
  'Run' { if ($Task -eq 'All') { throw 'Run requires one task.' }; Prepare-Task $Task; Run-Task $Task $Program }
  'Stop' { Stop-Lab }
  'Status' { $State | Select-Object DbPort,TomcatPort,Node9Port,Node10Port,Node11Port,ReactPort; $State.Processes | Format-Table Name,Pid; Write-Host "Lab folder: $LabHome" }
  'Hashes' { $records=Source-Hashes; Note "SHA256 verification passed for $($records.Count) deployed source files." }
 }
 if ($script:LastTaskExit) { exit $script:LastTaskExit }; exit 0
} catch { Note "ERROR: $($_.Exception.Message)"; exit 1 }
