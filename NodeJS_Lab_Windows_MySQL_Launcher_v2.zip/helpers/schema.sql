-- INFERRED from SQL statements in the supplied programs. No schema was supplied.
-- These are dedicated databases inside this launcher's private MySQL data folder.
CREATE DATABASE IF NOT EXISTS lab_studentdb CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS lab_studentdb.students (
 id INT PRIMARY KEY, name VARCHAR(255), age INT, email VARCHAR(255)
);
CREATE DATABASE IF NOT EXISTS lab_registrationdb CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS lab_registrationdb.logindetails (
 username VARCHAR(255), password VARCHAR(255), email VARCHAR(255), contactno VARCHAR(64)
);
CREATE DATABASE IF NOT EXISTS lab_collegedb CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS lab_collegedb.studentdetails (
 id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255), course VARCHAR(255)
);
CREATE DATABASE IF NOT EXISTS lab_collegedb1 CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS lab_collegedb1.studentdetails1 (
 id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255), course VARCHAR(255)
);
