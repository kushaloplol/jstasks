# Windows lab launcher — Tasks 4–12

Extract this entire ZIP to a writable folder, then double-click **START.bat**. Keep the folder contents together. Internet access is needed on first setup. Windows 10/11 x64 and Windows PowerShell 5.1 or newer are required.

Choose a task. The launcher detects compatible software, downloads missing portable tools from official sources, installs dependencies, places the supplied files, and compiles Java when required. It prints the full locations and launch address/command. Type **DONE** when ready. Task 6 Java CRUD and Task 9 each have a program submenu. Servers run in the background so the menu remains available. **S** stops lab servers; **0** exits and stops them. Closing the window abruptly can leave servers running: reopen START.bat and choose S.

## Files and data

- `original/`: unchanged files extracted from the student's ZIP. The original ZIP itself was never modified.
- `code/`: final configured study code. On a different computer, setup refreshes only configuration literals for that computer and copies these files automatically to the working folders.
- `lab/working/`: deployed Tasks 4, 5, 6, 9, 10, 11 and 12. Tasks 10 and 11 have separate `app.js` files, dependencies and ports.
- `lab/tomcat-base/webapps/Task7` and `Task8`: deployed servlet applications, including corresponding Java sources.
- `lab/tools/`, `lab/downloads/`: private portable tools and verified download cache. No global PATH changes or Windows service installation is required.
- `lab/mysql-data/`: isolated **Oracle MySQL** database files. Existing database services, databases and administrator passwords are untouched.
- `lab/state.json`: saved setup progress, selected ports and process identities. `lab/logs/`: setup/server logs. Secrets are not logged by the launcher.
- `lab/source-hashes.json`: current SHA-256 comparisons between `code/` and deployed source files.
- `verification/`: actual Windows test evidence for this delivery. Read `VERIFICATION_REPORT.md` for limitations.

Default ports are MySQL 13307, Tomcat 18080, Task 9 13009, Task 10 13010, Task 11 13011 and React 13012. If occupied by another program, setup chooses another free port and documents the new value in state/logs. Use the address printed by the launcher.

## Required inputs and task behavior

**Task 5 is now XML / DTD / XSD validation.** It automatically places `books.xml`, `booksinfor.dtd`, and `books.xsd` in `lab/working/Task5`. After DONE, it opens https://www.xmlvalidation.com/ and the local files folder. Upload the XML yourself, then provide the DTD when requested; for XSD, choose the external schema option and provide books.xsd. The supplied first book is missing its required price, so validation reports that original error. The files are preserved unchanged.

The previous combined Java practical is now **Task 6**, under `Tasks6`. Supplied output screenshots are excluded from this code package. The original archive README retains its old labels; use this README and TASKS.md for the current mapping.

Task 4 prompts for your **OpenWeather API key**, with hidden input. Press Enter to open the supplied HTML without a key; live weather values still require a key. The key must appear in the local HTML for this supplied browser application to use it; do not share your configured HTML with a private key. No key is included in this delivery.

Task 6 asks for student details in the terminal. UpdateData expects single-word name/email fields, matching the supplied Scanner approach. The schemas in `helpers/schema.sql` are **inferred from supplied SQL**, not supplied by the archive.

Task 7 opens `registration.html`. Task 8 prints addresses for both cookie and session forms; retrieval and logout links are supplied by the servlets. Their original behavior is retained, including cookie password storage and session login checking only whether the username is nonempty.

Tasks 10–11 are JSON APIs, so a browser GET is only a small part of their use. Routes are listed in `TASKS.md`. Task 11 retains the supplied demonstration login and JWT configuration in its source. No new authentication was added.

Task 12 uses the original Create React App package files and UI. Its Register and Login forms do not have a backend. Dependencies are installed with `npm ci`; `node_modules` is not bundled. Its original default test is retained even though it does not match this UI.

## Troubleshooting

Retry the task after correcting the error. Downloads and successful dependency installations are reused. Network downloads have bounded timeouts/retries; npm setup has a 12-minute limit per attempt. A checksum mismatch stops setup: remove only the named bad cached download and its `.check` file, then retry.

Read `lab/logs/launcher.log`, the named server's `.err.log` and `.out.log`, or the named npm log. Do not run the same extracted launcher folder concurrently in two terminals. Stop servers before moving the extracted folder; if moved, remove only `lab/state.json` to rediscover tools/processes after confirming those old servers are stopped. Keep `mysql-data` to preserve lab records.

If a missing Microsoft VC++ runtime is detected, setup obtains Microsoft's signed installer and opens the normal administrator approval prompt. Cancellation retains progress. A required Windows restart is reported. Portable Node/JDK/MySQL/Tomcat downloads are the normal path; this VC++ fallback and missing-Node/JDK paths were not needed on the tested computer.

If database initialization is interrupted, inspect `mysql-init.err.log`. Setup refuses to overwrite a nonempty incomplete data directory. Move aside only that private incomplete `lab/mysql-data` folder and retry; never point this launcher at an existing database administrator's data folder.

Advanced commands, from the extracted folder:

```bat
START.bat -Action Prepare -Task All
START.bat -Action Status
START.bat -Action Hashes
START.bat -Action Stop
START.bat -Action Run -Task 9 -Program event1.js
START.bat -Action Run -Task 6 -Program DisplayData
```

`-LabHome "D:\My Lab Data"` optionally places runtime files elsewhere. Ordinary first launch needs no command-line options. Source files, dependencies, compiled `.class` files, logs and build outputs are tracked separately; generated files are not represented as supplied source code.
