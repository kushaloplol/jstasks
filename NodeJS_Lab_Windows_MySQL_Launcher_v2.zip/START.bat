@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0helpers\Launcher.ps1" %*
set "LAB_EXIT=%ERRORLEVEL%"
popd
if not "%LAB_EXIT%"=="0" echo Launcher exited with code %LAB_EXIT%. See lab\logs for details.
exit /b %LAB_EXIT%
