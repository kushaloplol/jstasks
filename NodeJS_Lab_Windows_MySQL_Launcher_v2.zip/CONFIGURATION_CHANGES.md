# Configuration changes and preservation

Only eight supplied files have configuration-literal changes in `code/`. All other supplied files retain their original bytes. `original/` retains all 50 extracted entries unchanged.

| File(s) | Configuration change in final tested copies |
|---|---|
| Tasks6/InsertData.java, DisplayData.java, UpdateData.java, DeleteData.java | JDBC host becomes 127.0.0.1, all ports become 13307, database becomes lab_studentdb. Resolves original UpdateData port 3306 versus 3307 in its companions. |
| Task7/WEB-INF/classes/RegisterServlet.java | Ambiguous database URL becomes jdbc:mysql://127.0.0.1:13307/lab_registrationdb. Its blank-space password literal is configured for this newly initialized private MySQL account, matching the supplied Java CRUD lab credential. The credential value is deliberately omitted from this document. |
| Task9/server.js | Listening port 3000 becomes 13009. |
| Task10/app.js | Database becomes lab_collegedb; MySQL port becomes 13307; listening/logged server port becomes 13010. |
| Task11/app.js | Database becomes lab_collegedb1; MySQL port becomes 13307; listening/logged server port becomes 13011. |

On another machine, free-port selection may choose different values; the launcher refreshes only the same literals in final code and automatic deployment copies. No API key is included. Task 4's API key literal changes only when the user supplies their own key at launch; input is hidden and not logged.

Statement/PreparedStatement choices, SQL operations, method bodies, routes, servlet mappings, JWT configuration and React application approach remain as supplied. Task 10 and Task 11 are distinct files and run from distinct folders. Task 11's demonstration login and seven-day JWT expiry were not changed. Task 12, including its package files and stale default test, is unchanged.

Added launcher metadata is separate from supplied source: Task 9 receives a small `package.json` declaring its existing ES module approach; Tasks 10–11 receive dependency manifests/lockfiles with no change to their CommonJS approach. Compiled classes, JDBC jars, node_modules, logs, MySQL data, and React build output are generated runtime files and excluded from the final code ZIP.

Tomcat uses a separate CATALINA_BASE with a loopback HTTP connector (default 18080) and disabled shutdown TCP port. Original web.xml mappings are copied unchanged. MySQL is Oracle MySQL 8.4, uses a separate data directory, binds to loopback, and disables its unused X Protocol listener. Schema definitions are inferred, as labelled in helpers/schema.sql.

## Original defects and limits retained

- Weather has an empty API key and only logs fetch/data errors to the console; it does not present a friendly invalid-city/API-key message.
- Java UpdateData takes whitespace-delimited fields; UpdateData/DeleteData announce success without checking affected-row counts. Java SQL exceptions are printed and can still produce process exit code 0.
- Registration's ambiguous database URL and mismatched password needed configuration. It retains the legacy com.mysql.jdbc.Driver alias, which the selected Connector/J supports with a deprecation notice.
- Cookie login stores the submitted password in a cookie, and retrieval displays it, as supplied. Username cookie lifetime is 24 hours; password cookie lifetime is two minutes.
- Session login only checks for a nonempty username. Its configured inactive timeout is 90 days, not 90 minutes. Its mismatched heading markup is retained. Logout invalidates the session and sends the original three-second Refresh header.
- Tasks 10–11 expose the supplied JSON APIs and do not have a single-record GET endpoint. Their existing error/status behavior is retained.
- React Register/Login have no backend actions. Home1.js is unused. The original default App.test.js still expects “learn react”, which this app does not render; actual test-run outcome is in the verification report.

## Revision 2 launcher changes

Task 5 is XML validation through XMLValidation.com; the three supplied XML/DTD/XSD files are unchanged. The screenshot layouts match that site, but the screenshots have no visible address bar, so the exact screenshot URL cannot be established. The verified website supports the needed DTD and external XSD workflow. The prior combined Java CRUD is Task 6, in Tasks6. Weather now opens the HTML when its API key prompt is left blank. These changes are in the launcher, not the student programs. All supplied output screenshots are excluded; React public icons/logos are application assets and retained.
