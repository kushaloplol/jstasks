import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter pw = response.getWriter();
        String url = "jdbc:mysql://127.0.0.1:13307/lab_registrationdb";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, "root", "mgit@5");
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO logindetails(username,password,email,contactno) VALUES (?, ?, ?, ?)");

            ps.setString(1, request.getParameter("name"));
            ps.setString(2, request.getParameter("password"));
            ps.setString(3, request.getParameter("email"));
            ps.setString(4, request.getParameter("contact"));

            int rows = ps.executeUpdate();
            pw.println(rows > 0
                    ? "You are successfully registered!"
                    : "Registration failed.");
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            pw.println("An error occurred: " + e.getMessage());
        }
    }
}
