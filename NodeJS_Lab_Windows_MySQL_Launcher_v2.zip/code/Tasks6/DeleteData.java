import java.sql.*;
import java.util.Scanner;

public class DeleteData {
    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1:13307/lab_studentdb", "root", "mgit@5");
             Statement s = con.createStatement()) {

            Scanner sc = new Scanner(System.in);
            System.out.print("Enter student id: ");
            int id = sc.nextInt();

            s.executeUpdate("DELETE FROM students WHERE id=" + id);
            System.out.println("Data deleted successfully");
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
    }
}
