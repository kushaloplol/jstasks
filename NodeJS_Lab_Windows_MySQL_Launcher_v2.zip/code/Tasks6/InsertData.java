import java.sql.*;
import java.util.Scanner;

public class InsertData {
    public static void main(String[] args) {
        String url = "jdbc:mysql://127.0.0.1:13307/lab_studentdb";
        String sql = "INSERT INTO students (id, name,age,email) VALUES (?, ?, ?, ?)";
        Scanner sc = new Scanner(System.in);

        try {
            Connection con = DriverManager.getConnection(url, "root", "mgit@5");
            PreparedStatement ps = con.prepareStatement(sql);

            System.out.print("Enter student id: ");
            ps.setInt(1, sc.nextInt());
            sc.nextLine();
            System.out.print("Enter student name: ");
            ps.setString(2, sc.nextLine());
            System.out.print("Enter student age: ");
            ps.setInt(3, sc.nextInt());
            sc.nextLine();
            System.out.print("Enter students email: ");
            ps.setString(4, sc.nextLine());

            System.out.println(ps.executeUpdate() > 0
                    ? "Record Inserted Successfully!"
                    : "Record insertion failed.");
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
    }
}
