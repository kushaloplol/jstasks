# Task 12 shortened study copy

This is the React Router student-management UI from the supplied project, with unused comments and whitespace removed. It remains a front-end demonstration: the registration and login forms are not connected to a server or database.

Run with npm install followed by npm start. node_modules is not included; install dependencies from the included package files.

Home1.js is included but is not imported by App.js. App.test.js is the original Create React App test and still searches for the text “learn react”, which this app does not render.
