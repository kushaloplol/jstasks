import React from 'react';

function Home() {
  return (
    <div style={{ textAlign: 'center', padding: '50px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Welcome to the Student Management System</h1>
      <p>Manage registrations, logins, and student profiles efficiently.</p>
    </div>
  );
}

export default Home;
