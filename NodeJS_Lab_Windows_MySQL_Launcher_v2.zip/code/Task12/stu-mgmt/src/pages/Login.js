export default function Login() {
  return (
    <div>
      <h2>Login</h2>
      <input type="email" placeholder="Email" /><br />
      <input type="password" placeholder="Password" /><br />
      <button>Login</button>
    </div>
  );
}
