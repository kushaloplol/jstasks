import java.io.IOException;
import javax.servlet.http.*;

public class CookieLoginServlet extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        Cookie user = new Cookie("uname", username);
        Cookie pass = new Cookie("pwd", password);
        user.setMaxAge(60 * 60 * 24);
        pass.setMaxAge(2 * 60);

        res.addCookie(user);
        res.addCookie(pass);
        res.setContentType("text/html");
        res.getWriter().println(
            "<h2>Cookies Created Successfully</h2><a href='retrieve'>retrieve cookie details</a>");
    }
}
