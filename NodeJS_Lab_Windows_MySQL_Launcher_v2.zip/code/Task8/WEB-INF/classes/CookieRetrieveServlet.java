import java.io.IOException;
import javax.servlet.http.*;

public class CookieRetrieveServlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {
        String username = "", password = "";
        Cookie[] cookies = req.getCookies();

        if (cookies != null) {
            for (Cookie c : cookies) {
                if (c.getName().equals("uname")) username = c.getValue();
                if (c.getName().equals("pwd")) password = c.getValue();
            }
        }

        res.setContentType("text/html");
        res.getWriter().println("<h2>Welcome " + username + "</h2>");
        res.getWriter().println("<h3>Password: " + password + "</h3>");
    }
}
