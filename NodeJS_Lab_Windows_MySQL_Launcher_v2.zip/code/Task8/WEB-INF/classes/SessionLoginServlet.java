import java.io.*;
import javax.servlet.http.*;

public class SessionLoginServlet extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {
        res.setContentType("text/html");
        String username = req.getParameter("username");

        if (username != null && !username.isEmpty()) {
            HttpSession session = req.getSession();
            session.setAttribute("uname", username);
            session.setMaxInactiveInterval(3 * 30 * 24 * 60 * 60);

            PrintWriter out = res.getWriter();
            out.println("<h1>Login Successful</h2>");
            out.println("<h2>session created Successfully</h2>");
            out.println("<a href='retrieve1'> retrive session details</a>");
        } else {
            res.getWriter().println("Invalid Login!");
        }
    }
}
