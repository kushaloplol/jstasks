import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LogoutServlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        HttpSession session = req.getSession(false);

        if (session != null) session.invalidate();

        out.println("<h2>Session closed. Redirecting...</h2>");
        res.setHeader("Refresh", "3; URL=session.html");
    }
}
