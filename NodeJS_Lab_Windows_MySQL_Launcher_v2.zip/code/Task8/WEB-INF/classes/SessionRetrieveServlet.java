import java.io.*;
import javax.servlet.http.*;

public class SessionRetrieveServlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        HttpSession session = req.getSession(false);

        if (session != null && session.getAttribute("uname") != null) {
            String user = (String) session.getAttribute("uname");
            out.println("<h2>Welcome " + user + "</h2>");
            out.println("<a href='LogoutServlet'>Logout</a>");
        } else {
            out.println("<h2>No session found, login first</h2>");
        }
    }
}
