# Shortened Node.js Lab Study Codes — Tasks 4–12

This archive contains complete shortened study copies for Tasks 4 through 12. It does not modify the original ZIP or RAR. Task 10 and Task 11 remain separate programs.

## Contents

- Task 4: WeatherInfo2_1.html
- Tasks 5–6: InsertData.java, DisplayData.java, UpdateData.java, DeleteData.java
- Task 7: registration form and RegisterServlet, under WEB-INF
- Task 8: cookie and HTTP-session programs, forms, and combined web.xml
- Task 9: event1.js, os.js, path.js, server.js
- Task 10: its own app.js (Express/MySQL CRUD)
- Task 11: its own app.js (JWT login and protected CRUD)
- Task 12: compact React student-management source project

## Configuration and source notes

- Task 4 retains the original empty API key; set your own key to use OpenWeatherMap.
- Tasks 5–6 retain the supplied studentdb settings. UpdateData uses port 3306; the other three use 3307. DisplayData adds a tab between age and email because the source concatenated them.
- Task 7's PDF prints a database URL with the unclear suffix registrationdb5_ _ and a blank-space password. Set these to your actual MySQL database name and password. The PDF calls the form both register.html and registration.html.
- Task 8 stores the password in a cookie as plain text for two minutes, as the source does. The session login checks only for a non-empty username; it does not check the submitted password. The redundant inner session check was removed because it could never be false after the outer check passed.
- Task 9 uses ES module imports, while the outer lab folder has no package.json declaring module type. Task 9 and Tasks 10–11 all listen on port 3000; run them separately.
- Tasks 10–11 retain their original database names, ports, credentials, route names, and CRUD/JWT approaches.
- Task 12 is a front-end React demonstration, not a database-connected app. Its third-party node_modules folder is omitted; package.json and package-lock.json are included. Home1.js is unused, and the included default App.test.js still expects “learn react”.

The code reductions remove comments, unused markup, and repeated whitespace. Core task methods and routes are preserved; no new programming approach has been added.
